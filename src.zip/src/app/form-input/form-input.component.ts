import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-form-input',
  templateUrl: './form-input.component.html',
  styleUrls: ['./form-input.component.css']
})
export class FormInputComponent implements OnInit {

  constructor() { }
  fname:string= "";
  lname:string="";
  age:number|undefined;
  dob:Date|undefined;
  dept:string="";
  details :any  = {
    firstname:'',
    lastname:'',
    age:0,
    dob:new Date(),
    department : '',
    check : false
  };

  ngOnInit(): void {
  }

  submitDetails()
  {
    this.details.firstname = this.fname;
    this.details.lastname = this.lname;
    this.details.age = this.age;
    this.details.dob = this.dob;
    this.details.department = this.dept; 
    this.details.check = true;
    this.fname = '';
    this.lname = '';
    this.age = undefined;
    this.dob = undefined;
    this.dept = '';
  }

}
